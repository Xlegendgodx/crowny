const Discord = require('discord.js');
module.exports = {
    name: 'dm',
    description: 'dm a user',
    execute(client, message, args, database) {
        const devs = [
            '739215769862275123',
            '851439254046900244',
            '740459454222303256',
            '731762138929954817'
        ]

        if (devs.includes(message.author.id)) {
            const target = client.users.cache.get(args[0]);

            let payload = message.content.slice(8)

            client.users.cache.get(target.id).send(payload)
            message.channel.send("DM has been Sent <:tick:854208838952943626>")
        }
        else {
            message.channel.send("You don't have permission to use this command")
        }
    },
};