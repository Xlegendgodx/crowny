const Discord = require('discord.js');
module.exports = {
    name: 'add',
    description: 'adds money to an admin',
    execute(client, message, args, database) {
        const devs = [
            '739215769862275123',
            '851439254046900244',
            '740459454222303256',
            '731762138929954817'
        ]
        if (devs.includes(message.author.id)) {
					var str = message.content;
					var toAddFirst = str.toString().replace(/\D+/g, '');
					var toAdd = Number(toAddFirst);
          return database.ref(`/Economy/${message.author.id}/Cash`).once('value')
						.then((snapshot) => {
							var data = snapshot.val();
							var cash = Number(data)
							database.ref(`/Economy/${message.author.id}/Cash`).set(cash + toAdd)

							let collectEmbed = new Discord.MessageEmbed()
								.setColor("#12b4f4")
								.setDescription(`<:tick:854208838952943626> You took **${toAdd.toLocaleString()}** Crowncy <:crowncyCash2464:854278653339762708> as a admin`);
							message.channel.send(collectEmbed)
						});
        }
    }
}