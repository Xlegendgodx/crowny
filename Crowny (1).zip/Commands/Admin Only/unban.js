const Discord = require('discord.js');
module.exports = {
    name: 'unban',
    description: 'unprevent a user from using the bot',
    execute(client, message, args, database) {
        const devs = [
            '739215769862275123',
            '851439254046900244',
            '740459454222303256',
            '811253096570814486',
            '731762138929954817'
        ]

        if (devs.includes(message.author.id)) {
            var target = message.mentions.users.first();

						if(devs.includes(target.id)) {
							message.reply("User mentioned is an admin and cannot be banned and unbanned!")
						}

						else {
							database.ref(`/Bans/${target.id}`).set(null)
            	message.reply(`Unbanned ${target}!`)
						}
        }

        else {
            message.reply("You don't have permissions to use this command :/")
        }
    },
};