const Discord = require('discord.js');
module.exports = {
    name: 'eval',
    description: 'evauluate a command',
    execute(client, message, args, database) {
        const devs = [
            '739215769862275123',
            '851439254046900244',
            '740459454222303256',
            '731762138929954817'
        ]
        if (devs.includes(message.author.id)) {
					if (message.lenght < 11) {
						message.channel.send("Provide a command.....")
					}
					else {
						evalCmd = message.content.slice(12)
						eval(evalCmd)
					}
        }

				else {
					message.channel.send("You don't have permission to use this command!")
				}
    }
}