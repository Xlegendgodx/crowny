const Discord = require('discord.js');
module.exports = {
    name: 'ban',
    description: 'prevent a user from using the bot',
    execute(client, message, args, database) {
        const devs = [
            '739215769862275123',
            '851439254046900244',
            '740459454222303256',
            '731762138929954817'
        ]

        if (devs.includes(message.author.id)) {
            var target = message.mentions.users.first() || client.users.cache.get(args[0]);

						if(devs.includes(target.id)) {
							message.reply("You cannot ban admins!")
						}

						else {
							database.ref(`/Bans/${target.id}`).set(1)
            	message.reply(`Banned ${target} from using the bot!`)
						}
        }

        else {
            message.reply("You don't have permissions to use this command :/")
        }
    },
};