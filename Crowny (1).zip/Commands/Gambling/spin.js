const Discord = require('discord.js');

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

module.exports = {
	name: 'spin',
	description: 'gamble a certain amount on a roulette wheel',
	async execute(client, message, args, database) {
		var gambledAmount = Number(args[0])
    var randomTime = [3000,4000,5000]
    var pickrandomTime = Math.floor(Math.random() * randomTime.length);
		var pick = Math.floor(Math.random() * (3 - 1+1)+1);

		if (pick == 2) {
			database.ref(`/Economy/${message.author.id}/Cash`).once('value')
			.then((snapshot) => {
				var cash = snapshot.val();
				
				database.ref(`/Economy/${message.author.id}/Cash`).set(cash + gambledAmount)
			})

			const msg = await message.channel.send('<a:hype1:826313422395539526>')
			await sleep(pickrandomTime)
			msg.edit(`GG! You won **${gambledAmount} Crowncy <:crowncyCash2464:854278653339762708>**`)
		}

		else {
			database.ref(`/Economy/${message.author.id}/Cash`).once('value')
			.then((snapshot) => {
				var cash = snapshot.val();

				database.ref(`/Economy/${message.author.id}/Cash`).set(cash - gambledAmount)
			})

			const msg = await message.channel.send('<a:hype1:826313422395539526>')
			await sleep(pickrandomTime)
			msg.edit(`Oof! You lost **${gambledAmount} Crowncy <:crowncyCash2464:854278653339762708>**`)
		}
	},
};