const Discord = require('discord.js');
module.exports = {
    name: 'patreon',
    description: 'patreon exclusive perks',
    execute(client, message, args, database) {
    	message.channel.send(`:tickets: ${message.author.toString()} You can be Our Patreon Supporter and Claim Amazing Perks. For More Details Check Out here <:CWcowncy:852930607007793202>
      https://www.patreon.com/crowny`)
    },
};