const Discord = require('discord.js');
module.exports = {
	name: 'ping',
	description: 'get ping speed',
	execute(client, message, args, database) {
		message.channel.send(`🏓Latency is: ${Date.now() - message.createdTimestamp}ms`);
	},
};