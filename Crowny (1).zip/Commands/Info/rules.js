const Discord = require('discord.js');
module.exports = {
	name: 'rules',
	description: 'Rules of the Bot',
	execute(client, message, args, database) {
		const rulesEmbed = new Discord.MessageEmbed()
			.setTitle('RULES OF THE BOT')		
      .setDescription('When you Started Using Our Bot, that means you are agreeing to  Our Rules')
			.setColor('#12b4f4')
      .setThumbnail('https://cdn.discordapp.com/avatars/852919666292031509/9e132383457505f704fbaeed3c305ac4.webp?size=4096')
      .addField(`• Do Not Use Botting/any Other things`,'-----------------------------------')
      .addField(`• Do not Trade Crowncy Out Side of Discord or Anywhere `,'-----------------------------------')
      .addField(`• Do not use Many alt Account to make the Crowncy Higher`,'-----------------------------------')
      .setFooter('If anything above listed happens, then you will be banned from using the Bot \nAlso if you See anyone is not following the rules, then you can report them using\n`crowny report [mention the user]`')
		message.channel.send(rulesEmbed)
    .then(async (message) => {
			await message.react("✅")
		});
	},
};