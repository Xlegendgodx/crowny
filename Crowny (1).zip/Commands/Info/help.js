const Discord = require('discord.js');
module.exports = {
	name: 'help',
	description: 'get help from the Bot',
	execute(client, message, args, database) {
		const helpEmbed = new Discord.MessageEmbed()
			.setTitle('Help and Support')		
      .setThumbnail(message.guild.iconURL())	
      .setDescription('Need more help? Join Our [Support Server](https://discord.gg/nzhvPgSAP2)')
			.setColor('#12b4f4')
      .addField('📄 Rules', '`rules`')
			.addField('🏆 LeaderBoard', '`lb`')
			.addField('💰 Economy,', '`cash,`  `daily,` `give,` `hourly,` `monthly,` `weekly,` `work`')
      .addField('🎲 Gambling,','`luckydraw,` `spin,` `event,` `flip`')
			.addField('🤪 Fun', ' `kill,` `meme,` `hero,` `cry,` `laugh,` `angry,` `jail,` `dance,` `eject`')
      .addField('🛠 Utility',' `invite`, `avatar`, `report,` `review,` `suggest,` `prefix,` `vote`')
      .addField('🔒 Patreon','`patreon`')
      .addField('Get Crowny','[Invite](https://discord.com/api/oauth2/authorize?client_id=852919666292031509&permissions=1074120768&scope=bot)')
			.setAuthor(`Commands List`, message.author.displayAvatarURL())
			.setFooter('NOTE: If you Break the Rules..You will get Banned')
		message.channel.send(helpEmbed);
	},
};