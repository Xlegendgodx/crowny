const Discord = require('discord.js');
module.exports = {
    name: 'invite',
    description: 'invite the bot to a server',
    execute(client, message, args, database) {
       const helpEmbed = new Discord.MessageEmbed()
			.setTitle('Invite Crowny')
      .setDescription('Need Crowny in your Server? [Invite Crowny](https://discord.com/api/oauth2/authorize?client_id=852919666292031509&permissions=1074120768&scope=bot)')
			.setColor('#0B9DF1')
      .setFooter(`Command by ${message.author.tag}.`, message.author.displayAvatarURL());
      message.channel.send(helpEmbed);
    },
};