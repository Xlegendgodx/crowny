const Discord = require('discord.js');
module.exports = {
    name: 'laugh',
    description: 'Show laugh meme',
    execute(client, message, args, database) {

      const images = ['https://media.tenor.com/images/4c5f70f4857907605c43ac84c45cffda/tenor.gif','https://thumbs.gfycat.com/ConfusedRareDoe-max-1mb.gif','http://gifscenter.com/wp-content/uploads/2017/05/Obama%20laughing.gif']

     const answer = images[Math.floor(Math.random() * images.length)]

     const cryEmbed = new Discord.MessageEmbed()
          .setDescription(`${message.author} **IS LAUGHING...BUT WHY??** 🤔🤔`)
          .setImage(answer)
          .setColor('#12b4f4')
        message.channel.send(cryEmbed);
    },
}
;