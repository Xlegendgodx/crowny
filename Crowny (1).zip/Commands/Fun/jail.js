const Discord = require('discord.js');
module.exports = {
    name: 'jail',
    description: 'stuck in jail',
    execute(client, message, args, database) {
      if(!args[0]) return message.channel.send(' Specify a User Nooby 😡')
     const user = message.mentions.members.first()
      if(!user) return message.channel.send('You need to Specify a Valid User :/')
      if (user.id === message.author.id) return message.channel.send('Self KILL Spotted 🔎')

      const images = ['https://media.tenor.com/images/2b563669a09b94a61fea4cd17a3a7e02/tenor.gif','https://media1.tenor.com/images/0b0421e62e9e09b2c46b3b2671cd7567/tenor.gif?itemid=5417529','https://media.tenor.com/images/f06e17318c2de971663e4b70c4af91fe/tenor.gif']

     const answer = images[Math.floor(Math.random() * images.length)]

     const jailEmbed = new Discord.MessageEmbed()
          .setDescription(`${user} **IS STUCK IN JAIL Help him!** 😭😭`)
          .setImage(answer)
          .setColor('#12b4f4')
        message.channel.send(jailEmbed);
    },
}
;