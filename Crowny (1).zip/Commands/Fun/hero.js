const Discord = require('discord.js');
module.exports = {
    name: 'hero',
    description: 'hero',
    execute(client, message, args, database) {
     const heroEmbed = new Discord.MessageEmbed()
          .setDescription(`${message.author} **THINKS HIMSELF AS A HERO**`)
          .setImage('https://media.giphy.com/media/ICoxhc8wGbJ8k/giphy.gif')
          .setColor('#12b4f4')
        message.channel.send(heroEmbed);
    },
}
;