const Discord = require('discord.js');
module.exports = {
    name: 'angry',
    description: 'angryyyy',
    execute(client, message, args, database) {

      const images = ['https://media4.giphy.com/media/11tTNkNy1SdXGg/200.gif','https://i.pinimg.com/originals/9d/f5/47/9df5473084c7b868c54112f6d2ad1bb0.gif','https://i.pinimg.com/originals/df/14/7a/df147af3e20b10bce5668afdd653e4a6.gif']

     const answer = images[Math.floor(Math.random() * images.length)]

     const angryEmbed = new Discord.MessageEmbed()
          .setDescription(`${message.author} **IS ANGRY** 😠😠`)
          .setImage(answer)
          .setColor('#12b4f4')
        message.channel.send(angryEmbed);
    },
}
;