const Discord = require('discord.js');
module.exports = {
    name: 'cry',
    description: 'cry',
    execute(client, message, args, database) {

      const images = ['https://i.pinimg.com/originals/c7/eb/5b/c7eb5bbae52025b4d2ad9b8224022bd4.gif','https://thumbs.gfycat.com/HonestNarrowDartfrog-size_restricted.gif','https://monophy.com/media/l41YdDNnasCOd2TWo/monophy.gif']

     const answer = images[Math.floor(Math.random() * images.length)]

     const cryEmbed = new Discord.MessageEmbed()
          .setDescription(`${message.author} **IS CRYING** 😭😭`)
          .setImage(answer)
          .setColor('#12b4f4')
        message.channel.send(cryEmbed);
    },
}
;