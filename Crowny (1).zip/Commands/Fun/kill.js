const Discord = require('discord.js');
module.exports = {
    name: 'kill',
    description: 'kill',
    execute(client, message, args, database) {
    
      if(!args[0]) return message.channel.send(' Specify a User Nooby 😡')
     const user = message.mentions.members.first()
      if(!user) return message.channel.send('You need to Specify a Valid User :/')
      if (user.id === message.author.id) return message.channel.send('Self KILL Spotted 🔎')

     const images = ['https://media.tenor.com/images/d2d8e6eebc96d2b134812364c15b2960/tenor.gif','https://media.tenor.com/images/bafc48f1e9cd2b2b0cebcf59bd3101ac/tenor.gif','https://data.whicdn.com/images/70817173/original.gif']

     const answer = images[Math.floor(Math.random() * images.length)]
     const killEmbed = new Discord.MessageEmbed()
          .setDescription(`${message.author} **KILLED** ${user}** !** **RIP...**`)
          .setImage(answer)
          .setColor('#12b4f4')
        message.channel.send(killEmbed);
    },
};