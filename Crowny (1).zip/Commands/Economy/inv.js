const Discord = require('discord.js');
module.exports = {
	name: 'inv',
	description: 'get list of all your items',
	execute(client, message, args, database) {
		return database.ref(`/Economy/${message.author.id}/Items`).once('value')
			.then((snapshot) => {
				var data = snapshot.val();
				var items = [];

				var target = message.mentions.users.first();
				if (!target) {
					target = message.author
				}

				if (data == null) {
					message.channel.send(`:no_entry: Oof,Looks like **${target.username}** doesn't have anything in their inventory`)
				}

				else {

					for (var key in data) {
						if (data.hasOwnProperty(key)) {
							items.push([`\n${key} worth ${data[key].toLocaleString()}`]);
						}
					}

					const invEmbed = new Discord.MessageEmbed()
						.setTitle("💼 Inventory 💼")
						.setColor("#12b4f4")
						.addField(`${message.author.username}'s Inventory`, items)

					message.channel.send(invEmbed)
				}
			});
	},
};