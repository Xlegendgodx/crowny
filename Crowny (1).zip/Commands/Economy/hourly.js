const Discord = require('discord.js');
const ms = require("ms");

module.exports = {
	name: 'hourly',
	description: 'get the hourly reward',
	execute(client, message, args, database) {
		var timeout = 3600000;

		return database.ref(`/Economy/${message.author.id}/Rewards/Hourly`).once('value')
				.then((snapshot) => {
					var data = snapshot.val();
					var hourly = Number(data)

					if (timeout - (Date.now() - hourly) > 0) {
						let time = ms(Date.now() - timeout);

						let timeEmbed = new Discord.MessageEmbed()
							.setColor("#12b4f4")
							.setDescription(`<:wrong:854319131745320980> You've already collected your hourly reward`);
						message.channel.send(timeEmbed)
					}

					else {
						var moneyGot = 100;
						return database.ref(`/Economy/${message.author.id}/Cash`).once('value')
							.then((snapshot) => {
								var data = snapshot.val();
								var cash = Number(data)
								database.ref(`/Economy/${message.author.id}/Cash`).set(cash + moneyGot)
								database.ref(`/Economy/${message.author.id}/Rewards/Hourly`).set(Date.now())

								let collectEmbed = new Discord.MessageEmbed()
									.setColor("#12b4f4")
									.setDescription(`<:tick:854208838952943626> You've collected your hourly reward of **${moneyGot.toLocaleString()}** Crowncy <:crowncyCash2464:854278653339762708>`);
								message.channel.send(collectEmbed)
							});
					}
				});
	},
};