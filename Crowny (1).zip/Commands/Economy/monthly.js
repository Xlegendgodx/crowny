const Discord = require('discord.js');
const ms = require("ms");

module.exports = {
	name: 'monthly',
	description: 'get the monthly reward',
	execute(client, message, args, database) {
		var timeout = ms('31d');

		return database.ref(`/Economy/${message.author.id}/Rewards/Monthly`).once('value')
				.then((snapshot) => {
					var data = snapshot.val();
					var monthly = Number(data)

					if (timeout - (Date.now() - monthly) > 0) {
						let time = ms(Date.now() - timeout);

						let timeEmbed = new Discord.MessageEmbed()
							.setColor("#12b4f4")
							.setDescription(`<:wrong:854319131745320980> You've already collected your monthly reward. You can recollect in ${dhm(timeout - (Date.now() - monthly))}`);
						message.channel.send(timeEmbed)
					}

					else {
						var moneyGot = 50000;
						return database.ref(`/Economy/${message.author.id}/Cash`).once('value')
							.then((snapshot) => {
								var data = snapshot.val();
								var cash = Number(data)
								database.ref(`/Economy/${message.author.id}/Cash`).set(cash + moneyGot)
								database.ref(`/Economy/${message.author.id}/Rewards/Monthly`).set(Date.now())

								let collectEmbed = new Discord.MessageEmbed()
									.setColor("#12b4f4")
									.setDescription(`Hey My Dear Piggie **${message.author.username}**\nYou Got **${moneyGot.toLocaleString()}** Piggy Coins and a **Monthly Loot Box** as your **Monthly Reward**.\nYour Can Recollect it again in:\n 30 Days`);
								message.channel.send(collectEmbed)
							});
					}
				});
	},
};