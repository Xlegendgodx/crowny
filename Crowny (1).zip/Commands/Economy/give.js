const Discord = require('discord.js');
const numeral = require('numeral');
module.exports = {
    name: 'give',
    description: 'give coins',
    execute(client, message, args, database) {

			var target = message.mentions.users.first();

			var toPay = Number(message.content.slice(process.env.PREFIX.length).split(" ")[2])

			database.ref(`/Economy/${message.author.id}/Cash`).once('value')
			.then((snapshot) => {
				var data = snapshot.val();
				var cash = data

				if (cash == null) {
					cash = 0
				}

				if (toPay > cash) {
					message.channel.send(`:no_entry: Oof, You don't have enough Crowncy to pay to **${target.username}**`)
				} else {
					database.ref(`/Economy/${target.id}/Cash`).once('value')
					.then((snapshot) => {
						var data = snapshot.val();
						var targetCash = data

            if(target == message.author)
            {
              	let targetSelf = new Discord.MessageEmbed()
								.setColor("#12b4f4")
								.setDescription(`<:wrong:854319131745320980> **${message.author.username}** You are a Idiot? How can you sent Money to yourself?`);
								message.channel.send(targetSelf)
                return;
            }

						if (targetCash == null) {
							targetCash = 0
						}

						database.ref(`/Economy/${message.author.id}/Cash`).set(cash-toPay)
						database.ref(`/Economy/${target.id}/Cash`).set(targetCash+toPay)

						message.channel.send(`**${message.author.username}** Sent **${toPay.toLocaleString()}** Crowncy to **${target.username}** <:crowncyCash2464:854278653339762708>\n<:CWCard:854735557380276274> You now have **${(cash-toPay).toLocaleString()}** Crowncy Left <:crowncyCash2464:854278653339762708>`)
					})
				}
      });
    },
};