const Discord = require('discord.js');
const ms = require("ms");

module.exports = {
	name: 'daily',
	description: 'get the daily reward',
	execute(client, message, args, database) {
		var timeout = ms('1d');

		return database.ref(`/Economy/${message.author.id}/Rewards/Daily`).once('value')
				.then((snapshot) => {
					var data = snapshot.val();
					var daily = Number(data)

					if (timeout - (Date.now() - daily) > 0) {
						let time = ms(Date.now() - timeout);

						let timeEmbed = new Discord.MessageEmbed()
							.setColor("#12b4f4")
							.setDescription(`<:wrong:854319131745320980> You've already collected your daily reward`);
						  message.channel.send(timeEmbed)
					}

					else {
						var moneyGot = 5000;
						return database.ref(`/Economy/${message.author.id}/Cash`).once('value')
							.then((snapshot) => {
								var data = snapshot.val();
								var cash = Number(data)
								database.ref(`/Economy/${message.author.id}/Cash`).set(cash + moneyGot)
								database.ref(`/Economy/${message.author.id}/Rewards/Daily`).set(Date.now())

								let collectEmbed = new Discord.MessageEmbed()
									.setColor("#12b4f4")
									.setDescription(`<:tick:854208838952943626> You've collected your daily reward of **${moneyGot.toLocaleString()}** Crowncy <:crowncyCash2464:854278653339762708>`);
								message.channel.send(collectEmbed)
							});
					}
				});
	},
};