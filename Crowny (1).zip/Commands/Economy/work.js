const Discord = require('discord.js');
const ms = require("ms");

module.exports = {
	name: 'work',
	description: 'work to earn money',
	execute(client, message, args, database) {
		var timeout = 86400000;

		return database.ref(`/Economy/${message.author.id}/Rewards/Work`).once('value')
				.then((snapshot) => {
					var data = snapshot.val();
					var work = Number(data)

					if (timeout - (Date.now() - work) > 0) {
						let time = ms(timeout - Date.now());

						let timeEmbed = new Discord.MessageEmbed()
							.setColor("#12b4f4")
							.setDescription(`<:wrong:854319131745320980> You've already worked enough for the day!`);
						message.channel.send(timeEmbed)
					}

					else {
						var moneyGot = 2000;
						return database.ref(`/Economy/${message.author.id}/Cash`).once('value')
							.then((snapshot) => {
								var data = snapshot.val();
								var cash = Number(data)
								database.ref(`/Economy/${message.author.id}/Cash`).set(cash + moneyGot)
								database.ref(`/Economy/${message.author.id}/Rewards/Work`).set(Date.now())

								let collectEmbed = new Discord.MessageEmbed()
									.setColor("#12b4f4")
									.setDescription(`<:tick:854208838952943626> You worked hard for a few hours and earned ${moneyGot.toLocaleString()} Crowncy <:crowncyCash2464:854278653339762708>`);
								message.channel.send(collectEmbed)
							});
					}
				});
	},
};