const Discord = require('discord.js');
const numeral = require('numeral');
module.exports = {
	name: 'cash',
	description: 'check your crowny cash',
	execute(client, message, args, database) {
		var target = message.mentions.users.first();
		if (!target) {
			target = message.author
		}

		database.ref(`/Economy/${target.id}/Cash`).once('value')
			.then((snapshot) => {
				var data = snapshot.val();
				var cash = data

				if (cash == null) {
					cash = 0
				}

				const balEmbed = new Discord.MessageEmbed()
					.setAuthor(`Balance Crowncy`, target.displayAvatarURL())
          .setDescription(`**${target.username}** has **${cash.toLocaleString()}** Crowncy <:crowncyCash2464:854278653339762708>`)
          .setColor('#12b4f4')

				message.channel.send(balEmbed);
      });
	},
};