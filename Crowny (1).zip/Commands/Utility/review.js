const Discord = require('discord.js');
module.exports = {
	name: 'review',
	description: 'write a review on what you feel about the bot!',
	execute(client, message, args) {
		const staffChannel = client.channels.cache.find(channel => channel.id === "853233678732492831")
		let reason = message.content.slice(14)
		if (!reason) return message.reply(`Please provide a review`);

		message.delete()
		authorId = message.author.id
		message.channel.send('Your review has been sent to the team').then(m => m.delete({ timeout: 3000 }));
		const suggestEmbed = new Discord.MessageEmbed()
			.setColor(`#15d2e3`)
			.setTitle(`>>NEW REVIEW<<`)
			.addField(`Reviewer`, `${message.author}`)
			.addField(`Review`, `${reason}`)
		staffChannel.send(suggestEmbed)
		.then(async (message) => {
			await message.react("👍🏼")
			message.react("👎🏼")
		});
	},
};