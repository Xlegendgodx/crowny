const Discord = require('discord.js');
module.exports = {
	name: 'suggest',
	description: 'suggest a new feature for the bot!',
	execute(client, message, args) {
		const staffChannel = client.channels.cache.find(channel => channel.id === "852094064345088038")
		let reason = message.content.slice(15)
		if (!reason) return message.reply(`Please provide a suggestion`);

		message.delete()
		authorId = message.author.id
		message.channel.send('Your suggestion has been sent to the staff team').then(m => m.delete({ timeout: 3000 }));
		const suggestEmbed = new Discord.MessageEmbed()
			.setColor(`#15d2e3`)
			.setTitle(`>>NEW SUGGESTION<<`)
			.addField(`Suggester`, `${message.author}`)
			.addField(`Suggestion`, `${reason}`)
		staffChannel.send(suggestEmbed)
		.then(async (message) => {
			await message.react("✅")
			message.react("❎")
		});
	},
};