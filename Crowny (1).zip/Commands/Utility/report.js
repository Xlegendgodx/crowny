const Discord = require('discord.js');
module.exports = {
	name: 'report',
	description: "report a user for their misdoings",
	execute(client, message, args) {
		const staffChannel = client.channels.cache.find(channel => channel.id === "852094064345088039")
		let target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
			if (!target) return message.channel.send('Please provide a user that you wish to report');

			let reason = message.content.slice(36)
			if (!reason) return message.channel.send(`Please provide a reason for reporting`);

			message.delete()
			message.channel.send('Your report has been sent to the team').then(m => m.delete({ timeout: 3000 }));
			const reportEmbed = new Discord.MessageEmbed()
				.setColor(`#f01515`)
				.setTitle(`>>NEW REPORT<<`)
				.setThumbnail(`https://i.pinimg.com/736x/88/7d/92/887d92ad176aed37b3ba643518e2295c.jpg`)
				.addField(`Accuser`, `${message.author}`)
				.addField(`Accused`, `@${target.user.id}`)
				.addField(`Reason`, `${reason}`)
			staffChannel.send(reportEmbed)
      .then(async (message) => {
			await message.react("👍🏼")
			message.react("👎🏼")
		});
	},
};