const Discord = require('discord.js');
module.exports = {
	name: 'prefix',
	description: 'change the prefix',
	execute(client, message, args, database) {
		if (!message.member.hasPermission("MANAGE_GUILD")) {
			message.channel.send(':no_entry: You need MANAGE_SERVER')
    } else 
    {
      database.ref(`/Server-Info/${message.guild.id}/Prefix`).once('value')
			.then((snapshot) => {
				var prefix;
				if (snapshot.val() == null) {
					prefix = process.env.PREFIX;
				} else {
					prefix = snapshot.val();
				}
				var newPrefixFirst = message.content.slice(prefix.length)
				var newPrefix = newPrefixFirst.slice(7)
        newPrefix = newPrefix.concat(' ')
				console.log(`${prefix}\n${newPrefixFirst}\n${newPrefix}`)
			
				database.ref(`/Server-Info/${message.guild.id}/Prefix`).set(newPrefix)
				message.channel.send(`New prefix for **${message.guild.name}** has been set to **${newPrefix}**`)
			})
    }
	},
};
