const Discord = require('discord.js');

const fs = require('fs');
const client = new Discord.Client();
const moment = require('moment-timezone');

const firebase = require("firebase");

const firebaseConfig = {
	apiKey: "AIzaSyBpD5whtFiDwzkFPJzAix5JI5M-CyV3Pxg",
	authDomain: "crowny-bot.firebaseapp.com",
	databaseURL: "https://crowny-bot-default-rtdb.firebaseio.com",
	projectId: "crowny-bot",
	storageBucket: "crowny-bot.appspot.com",
	messagingSenderId: "45314895046",
	appId: "1:45314895046:web:d9c257a29722de1ea9fbc7",
	measurementId: "G-7EYSCPMXT7"
};


firebase.initializeApp(firebaseConfig);
const database = firebase.database();

const express = require('express');
const app = express();
const port = 3003;

app.get('/', (req, res) => res.send('Alive'));

app.listen(port, () => console.log(`Listening on ${port}`));
'use strict';

client.commands = new Discord.Collection();

var commandFolders = fs.readdirSync('./Commands');
for (var folder of commandFolders) {
	var cmdFiles = fs.readdirSync(`./Commands/${folder}`).filter(file => file.endsWith('.js'));
	for (var file of cmdFiles) {
		var command = require(`./Commands/${folder}/${file}`);
		client.commands.set(command.name, command);
	}
}

// const status = `${guilds} servers`

client.on('guildMemberAdd', async () => {
	const guilds = await client.guilds.cache.size;
	client.user.setActivity(` crowny help`, {
		type: 'PLAYING'
	});
});

client.on('ready', async () => {
	const guilds = await client.guilds.cache.size;

	var istTime = moment().tz('Asia/Kolkata').format('DD|MM|YYYY HH:mm');

	console.log(`Init Complete, Crowny Bot is online`);
	console.log(`Bot came online on ${istTime}`);
	client.user.setActivity(` crowny help`, {
		type: 'PLAYING'
	});
});

client.on('message', async message => {
	if (message.author.bot) return;

	database.ref(`/Bans/${message.author.id}`).once('value')
		.then((snapshot) => {
			var bansData = snapshot.val();

			database.ref(`/Server-Info/${message.guild.id}/Prefix`).once('value')
			.then((snapshot) => {
				var prefixData = snapshot.val();

				if (prefixData == null) {
					const prefix = process.env.PREFIX
					
					if (bansData == null) {
						const msg = message.content.toLowerCase();
						if (!msg.startsWith(prefix)) return;
						const args = msg.slice(prefix.length).split(" ");
						const cmd = args.shift().toLowerCase();

						client.commands.get(cmd).execute(client, message, args, database);
					}
					else {
						if (!msg.startsWith(prefix)) return;
						message.reply('You are banned from using this bot').then(m => m.delete({ timeout: 3000 }));
					}
				}

				else {
					const prefix = prefixData

					if (bansData == null) {
						const msg = message.content.toLowerCase();
						if (!msg.startsWith(prefix)) return;
						const args = msg.slice(prefix.length).split(" ");
						const cmd = args.shift().toLowerCase();

						client.commands.get(cmd).execute(client, message, args, database)
					}
					else {
						if (!msg.startsWith(prefix)) return;
						message.reply('You are banned from using this bot').then(m => m.delete({ timeout: 5000 }));
					}
				}
			})
		});
});

client.login(process.env.TOKEN);